// Homepage: renders the tool grid as real links to dedicated pages
// (each with its own URL, title and content — see /tools/*.html) and
// wires up the category filter pills. No upload logic lives here anymore;
// that's handled per-page by tool-widget.js.

const ICONS = {
  merge: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M8 3v9a4 4 0 0 0 4 4h4M16 12l-3-3m3 3-3 3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  split: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 3v6m0 0-8 6m8-6 8 6M4 21h4m-4 0v-4m0 4 5-5m11 5h-4m4 0v-4m0 4-5-5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  rotate: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M21 12a9 9 0 1 1-3-6.7M21 3v5h-5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  numbers: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M4 6h16M4 12h16M4 18h7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><text x="17" y="21" font-size="7" fill="currentColor">3</text></svg>',
  compress: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M9 4H4v5m16-5h-5m5 0v5M9 20H4v-5m16 5h-5m5 0v-5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  watermark: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 3 4 7v6c0 4.5 3.4 7.7 8 8 4.6-.3 8-3.5 8-8V7l-8-4Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
  wordpdf: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="4" y="3" width="16" height="18" rx="2" stroke="currentColor" stroke-width="1.6"/><path d="M8 9h8M8 13h8M8 17h5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
  jpg: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="16" rx="2" stroke="currentColor" stroke-width="1.6"/><circle cx="9" cy="10" r="1.6" fill="currentColor"/><path d="M4 17l5-5 4 4 3-3 4 4" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
  ppt: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="4" y="3" width="16" height="18" rx="2" stroke="currentColor" stroke-width="1.6"/><circle cx="10.5" cy="11" r="2.6" stroke="currentColor" stroke-width="1.5"/></svg>',
  xls: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="4" y="3" width="16" height="18" rx="2" stroke="currentColor" stroke-width="1.6"/><path d="M8 8l8 8M16 8l-8 8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
};

const ICON_BY_ID = {
  merge:'merge', split:'split', rotate:'rotate', numbers:'numbers', compress:'compress',
  watermark:'watermark', 'word-to-pdf':'wordpdf', 'ppt-to-pdf':'ppt', 'xls-to-pdf':'xls',
  'jpg-to-pdf':'jpg', 'pdf-to-word':'wordpdf', 'pdf-to-ppt':'ppt', 'pdf-to-xls':'xls', 'pdf-to-jpg':'jpg'
};

const toolGrid = document.getElementById('toolGrid');

function renderGrid(){
  toolGrid.innerHTML = TOOLS.map((t) => `
    <a class="tool-card" href="tools/${t.slug}.html" data-group="${t.group}" data-cat="${t.cat}">
      <span class="icon-badge">${ICONS[ICON_BY_ID[t.id]] || ''}</span>
      <h2>${t.title}</h2>
      <p>${t.desc}</p>
    </a>
  `).join('');
  observeCards();
}

// Reveal cards with a gentle staggered fade-up as they scroll into view.
function observeCards(){
  const cards = toolGrid.querySelectorAll('.tool-card');
  if (!('IntersectionObserver' in window)) {
    cards.forEach((c) => c.classList.add('is-visible'));
    return;
  }
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => entry.target.classList.add('is-visible'), i * 40);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
  cards.forEach((c) => observer.observe(c));
}

const filterBar = document.getElementById('filterBar');
filterBar.addEventListener('click', (e) => {
  const pill = e.target.closest('.filter-pill');
  if (!pill) return;
  filterBar.querySelectorAll('.filter-pill').forEach((p) => p.classList.remove('is-active'));
  pill.classList.add('is-active');
  const filter = pill.dataset.filter;
  toolGrid.querySelectorAll('.tool-card').forEach((card) => {
    const show = filter === 'all' || card.dataset.group === filter;
    card.classList.toggle('is-hidden', !show);
  });
});

document.querySelectorAll('[data-scrollfilter]').forEach((link) => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    document.getElementById('tools').scrollIntoView({ behavior: 'smooth' });
    const target = link.dataset.scrollfilter;
    const pill = filterBar.querySelector(`[data-filter="${target}"]`);
    if (pill) pill.click();
  });
});

renderGrid();
